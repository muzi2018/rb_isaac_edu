

# TODO: Make this as dataclass

FRANKA_NORMAL_USD_PATH = "omniverse://localhost/Projects/ETRI/Manipulator/Franka/franka_realsense.usd"
FRANKA_2F_USD_PATH = "omniverse://localhost/Projects/ETRI/Manipulator/Franka/franka_2f85.usd"
FRANKA_3F_USD_PATH = "omniverse://localhost/Projects/ETRI/Manipulator/Franka/franka_3f.usd"

ENV_BASE_PATH = "omniverse://localhost/Projects/ETRI/Env"
