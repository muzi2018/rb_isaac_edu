
test_str = "Hello Etri Bridge!"

class ETRIBridge():
    def __init__(self):
        self.test_str = test_str
        return
    
    def get_test_str(self):
        return self.test_str